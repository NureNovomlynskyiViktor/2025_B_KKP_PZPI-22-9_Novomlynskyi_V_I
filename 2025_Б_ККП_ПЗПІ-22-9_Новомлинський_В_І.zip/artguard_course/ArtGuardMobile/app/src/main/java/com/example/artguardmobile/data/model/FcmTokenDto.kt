package com.example.artguardmobile.data.model

data class FcmTokenDto(
    val token: String
)
